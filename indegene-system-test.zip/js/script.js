
let menuToggle = document.getElementById('toggleMenu')
menuToggle.addEventListener('click', function(event){
    let refId = event.toElement.dataset.ref;
    document.querySelector(refId).classList.toggle('active')
})